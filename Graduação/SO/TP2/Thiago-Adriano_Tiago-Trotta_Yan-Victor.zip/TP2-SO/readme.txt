Execução:
	
	1) make
	2) ./tp2virtual <substituição> <entrada> <tamanho_pagina> <tamanho_memoria> <debug>

		substiuição: lru, nru, segunda_chance
		tamanho_pagina: valores razoáveis: de 2 a 64
		tamanho_memoria: valores razoáveis: de 128 a 16384
		debug: (opcional) para execução em detalhes: 1
		